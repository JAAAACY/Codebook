# CodeBook — 流水线任务 Prompt 模板

> 每个模板是一段可以直接复制到 Claude Code 的完整任务指令。
> 使用前替换 `{{变量}}` 为实际值。

---

## 通用前缀（每个任务开头都要加）

```
先读取以下文件了解项目上下文：
1. CLAUDE.md — 项目规则
2. CONTEXT.md — 当前进度
3. INTERFACES.md — 模块接口

读完后确认你理解了当前 sprint 目标和本次任务所属的流水线，然后开始执行。
```

---

## 流水线 A：压力测试 + 引擎优化

### A-1：环境准备（clone 测试仓库）

```
【任务】流水线 A / 环境准备
【目标】clone 压力测试用的开源项目到 repos/ 目录

执行步骤：
1. cd repos/
2. git clone --depth 1 {{repo_url}}
3. 统计该项目的文件数和代码行数（用 cloc 或 find+wc）
4. 将统计结果写入 test_results/{{project_name}}/stats.json
5. 在 CONTEXT.md 中更新该项目的状态为"已clone"

不要做其他任何事情。
```

### A-2：scan_repo 压力测试

```
【任务】流水线 A / scan_repo 压力测试
【目标】对 {{project_name}} 运行 scan_repo，收集性能和质量指标

执行步骤：
1. 对 repos/{{project_name}} 运行 scan_repo（overview 模式）
2. 记录以下指标到 test_results/{{project_name}}/scan_repo.json：
   - 扫描总耗时（ms）
   - 识别的模块数量
   - 识别的符号数量
   - 生成的 Mermaid 图节点数
   - 是否出现错误或警告
3. 人工评估（写入同一 JSON）：
   - 模块分组是否合理？（1-10 分 + 简要说明）
   - Mermaid 图是否可读？（如果节点 > 50，标注"过密"）
4. 如果出现崩溃或超时，记录完整错误信息
5. 再用 detailed 模式运行一次，记录差异

完成后在 CONTEXT.md 追加任务日志。
```

### A-3：read_chapter + diagnose 压力测试

```
【任务】流水线 A / read_chapter + diagnose 压力测试
【目标】对 {{project_name}} 测试模块卡片和问题定位能力

执行步骤：

read_chapter 测试：
1. 从 scan_repo 结果中选 3 个不同规模的模块（小/中/大）
2. 对每个模块运行 read_chapter
3. 记录到 test_results/{{project_name}}/read_chapter.json：
   - 每个模块的响应时间
   - 子组件是否完整列出
   - 跨文件依赖是否被正确识别（人工检查 3 个关键依赖）
   - 翻译质量（PM 视角 1-10）

diagnose 测试：
4. 设计 2 个问题场景：
   - 场景 1：需要跨 3+ 文件追踪的 bug（如"用户注册后邮件没发出去"）
   - 场景 2：需要理解业务逻辑的问题（如"VIP 用户的折扣计算是否正确"）
5. 对每个场景运行 diagnose
6. 记录到 test_results/{{project_name}}/diagnose.json：
   - 定位的文件和行号是否准确
   - 调用链是否完整（有没有跳过中间节点）
   - Mermaid 流程图是否可读
   - 根因假设是否合理

完成后在 CONTEXT.md 追加任务日志。
```

### A-4：ask_about + codegen 压力测试

```
【任务】流水线 A / ask_about + codegen 压力测试
【目标】对 {{project_name}} 测试问答和代码生成能力

执行步骤：

ask_about 测试：
1. 选 1 个核心业务模块
2. 用 PM 视角连续提问 3 轮（测试多轮对话）：
   - "这个模块是做什么的？"
   - "如果我要加一个新功能 {{feature}}，需要改哪里？"
   - "改完之后怎么验证没有影响其他功能？"
3. 记录到 test_results/{{project_name}}/ask_about.json：
   - 每轮回答的翻译质量（PM 视角 1-10）
   - 多轮对话是否保持上下文连贯
   - 是否出现幻觉（引用不存在的文件或函数）

codegen 测试：
4. 设计 1 个涉及多文件修改的需求：
   "{{modification_instruction}}"
5. 先用 diagnose 定位，再用 codegen 生成修改
6. 记录到 test_results/{{project_name}}/codegen.json：
   - diff 是否语法正确（能否 apply）
   - 影响范围分析是否完整
   - 验证步骤是否可操作
   - 是否遗漏需要修改的文件

完成后在 CONTEXT.md 追加任务日志。
```

### A-5：瓶颈分析与优化

```
【任务】流水线 A / 瓶颈分析与优化
【目标】根据 {{project_name}} 的测试结果，定位并修复最严重的瓶颈

执行步骤：
1. 读取 test_results/{{project_name}}/ 下所有 JSON 结果
2. 按严重程度排序问题（崩溃 > 超时 > 质量下降 > 轻微问题）
3. 选择最严重的 1 个问题，分析根因
4. 实施修复（只修一个问题，保持改动最小化）
5. 跑 pytest 全量测试确认不回退
6. 对同一项目重新跑受影响的 tool 验证修复效果
7. 将修复前后的指标对比写入 test_results/{{project_name}}/optimization_log.json

完成后在 CONTEXT.md 追加任务日志。
不要一次修多个问题。一个任务一个修复。
```

---

## 流水线 B：PM↔Dev 桥梁模型

### B-1：现有 Prompt 分析

```
【任务】流水线 B / 现有 Prompt 分析
【目标】分析当前 4 角色 prompt 系统的问题，为桥梁模型重构做准备

执行步骤：
1. 读取 src/config/ 下的 prompt 配置文件
2. 对比 4 个角色的输出差异，列出：
   - 哪些差异是有意义的（真正改变了信息内容）
   - 哪些差异只是措辞替换（无实质区别）
3. 收集 PM 视角的典型问题模式（至少 10 个）
4. 设计 PM↔Dev 双视图的 prompt 架构草案
5. 将草案写入 docs/bridge_model_design.md

完成后在 CONTEXT.md 追加任务日志。
这个任务只做分析和设计，不写实现代码。
```

### B-2：桥梁模型实现

```
【任务】流水线 B / 桥梁模型实现
【目标】实现 PM↔Dev 桥梁模型，替换现有 4 角色系统

前置条件：确认 docs/bridge_model_design.md 中的设计方案已被认可。

执行步骤：
1. 按设计方案修改 prompt 配置
2. 保持对外接口向后兼容（旧角色名映射到新模型）
3. 对现有 4 个测试仓库跑 ask_about，收集新旧对比
4. 质量评估：PM 视角打分（目标 ≥ 9.0/10）
5. 跑 pytest 全量测试
6. 更新 INTERFACES.md 中的角色系统接口

完成后在 CONTEXT.md 追加任务日志。
```

---

## 流水线 C：测试补全 + CI

### C-1：修复已知测试问题

```
【任务】流水线 C / 修复已知测试问题
【目标】修复 I-001（断言未更新）和激活 I-002（Conduit 集成测试）

执行步骤：
1. 修复 test_mcp_server_has_four_tools → 改为断言 5 个 tool
2. 分析 25 项 Conduit 集成测试跳过的原因
3. 如果是环境依赖，配置必要的 fixture 或 mock
4. 逐步激活测试，确保每激活一批都能通过
5. 跑 pytest 全量测试，目标：0 跳过（或记录无法解决的跳过原因）

完成后在 CONTEXT.md 追加任务日志。
```

### C-2：建立 CI Pipeline

```
【任务】流水线 C / 建立 CI Pipeline
【目标】配置 GitHub Actions，每次 push 自动跑 pytest

执行步骤：
1. 创建 .github/workflows/test.yml
2. 配置：Python 3.10+、安装依赖、跑 pytest
3. 确保 CI 环境能访问测试所需的资源（或用 mock 替代）
4. 本地验证 workflow 文件语法
5. 在 README.md 中添加 CI badge

完成后在 CONTEXT.md 追加任务日志。
```

---

## 使用说明

1. **选择任务**：根据 CONTEXT.md 中的流水线状态，选择下一个待执行的任务
2. **替换变量**：将 `{{变量}}` 替换为实际值
3. **加上通用前缀**：每个任务开头都要加通用前缀
4. **复制到 Claude Code**：整段复制，不要省略任何步骤
5. **执行完毕后检查**：确认 CONTEXT.md 已更新、pytest 已通过
