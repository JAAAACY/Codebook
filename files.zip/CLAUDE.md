# CodeBook — Claude Code 项目规则

> 本文件由所有 Claude Code session 自动加载。内容为不可变规则，非动态进度。
> 动态进度见 `CONTEXT.md`，模块接口契约见 `INTERFACES.md`。

---

## 项目定义

CodeBook 是一个 MCP Server，让不会写代码的人能用自然语言理解代码、定位问题、生成修改方案。
采用「蓝图 → 看懂 → 定位 → 改码」四步能力模型。
当前版本：codebook-mcp-server 0.1.0。

---

## 技术栈约束（不可变）

| 层 | 技术 | 备注 |
|---|---|---|
| 语言 | Python 3.10+ | 不迁移到其他语言 |
| MCP 框架 | FastMCP | 不换框架 |
| AST 解析 | Tree-sitter (py-tree-sitter) | 核心解析器，不替换 |
| 依赖图 | NetworkX | 模块/函数级依赖关系 |
| 日志 | structlog | 所有日志必须用 structlog |
| 测试 | pytest | 所有新代码必须附带测试 |

---

## 代码结构（不可随意变更目录布局）

```
codebook-mcp-server/
├── src/
│   ├── server.py          # MCP 服务入口（173 行），不要随意修改 tool 注册逻辑
│   ├── tools/             # 5 个 MCP tool 实现（~3,791 行）
│   │   ├── scan_repo.*    # 蓝图扫描
│   │   ├── read_chapter.* # 模块卡片
│   │   ├── diagnose.*     # 问题定位
│   │   ├── ask_about.*    # 追问对话
│   │   └── codegen.*      # 代码生成
│   └── parsers/           # Tree-sitter 解析器（~1,312 行）
├── tests/                 # pytest 测试（9 文件，197 用例）
├── repos/                 # 测试用第三方仓库
├── CLAUDE.md              # 本文件
├── CONTEXT.md             # 动态进度
├── INTERFACES.md          # 模块接口契约
└── DEV_LOG.md             # 开发日志
```

---

## 5 个 MCP Tools（不可删除或重命名）

| Tool | 功能 | 输入 | 输出 |
|------|------|------|------|
| `scan_repo` | 克隆仓库 → AST 解析 → 模块分组 → 依赖图 | repo_url, depth | 蓝图 JSON + Mermaid 图 |
| `read_chapter` | 查看模块详情：子组件、调用关系、分支逻辑 | module_name | 模块卡片 |
| `diagnose` | 自然语言描述 → 调用链追踪 → file:line 定位 | description, module_name? | Mermaid 流程图 + 定位 |
| `ask_about` | 基于代码上下文的自由问答 | module_name, question, history? | 自然语言回答 |
| `codegen` | 自然语言指令 → unified diff + 影响范围 | instruction, locate_result | diff + 验证步骤 |

**新增 tool 需要同步更新：** server.py 注册、tests/ 测试、INTERFACES.md 接口定义、DEV_LOG.md。

---

## 编码规范

1. **所有新代码必须附带 pytest 测试**，覆盖正常路径 + 至少一个异常路径
2. **不引入新的重依赖**——如需新库，先在 CONTEXT.md 中记录理由，等待确认
3. **日志一律用 structlog**，禁止 print / logging.getLogger
4. **错误处理**：对外返回友好提示，不暴露 traceback；内部用 structlog 记录详细错误
5. **类型注解**：所有公共函数必须有完整的类型注解
6. **commit 信息格式**：`[模块] 简述`，如 `[scan_repo] 增加增量扫描支持`

---

## 禁止事项

- ❌ 不要修改 `server.py` 的 tool 注册逻辑，除非明确在任务中要求
- ❌ 不要删除或跳过现有测试用例（可以新增，不可删除）
- ❌ 不要硬编码 API Key 或模型名称到代码中
- ❌ 不要把 repos/ 下的测试仓库代码提交到 CodeBook 自己的仓库
- ❌ 不要引入 async/await 到当前同步架构中（除非任务明确要求重构）
- ❌ 不要在单个 session 中同时修改两个以上 tool 的核心逻辑

---

## 每个 session 的标准流程

### 开始时
1. 读取 `CONTEXT.md` 了解当前进度和本次任务
2. 读取 `INTERFACES.md` 确认模块接口
3. 明确本次任务的单一目标和验收标准

### 进行中
4. 每完成一个子步骤，跑 `pytest` 确认不回退
5. 如果需要改接口，**先更新 INTERFACES.md，再改代码**

### 结束时
6. 跑全量 `pytest`，报告通过率
7. 在 `CONTEXT.md` 追加本次任务总结（使用固定格式，见 CONTEXT.md）
8. 如有需要，更新 `DEV_LOG.md`

---

## 质量红线

- 全量 pytest 通过率 ≥ 99%（当前基线：99.3%）
- 任何 tool 的响应不允许出现 Python traceback
- PM 视角翻译质量评分不低于 9.0/10（当前基线：9.5/10）

---

## 并行开发规则

当多个 Claude Code session 并行工作时：
1. 每个 session 只负责一条流水线，不跨线操作
2. 修改接口前必须先更新 `INTERFACES.md` 并在 CONTEXT.md 中标注
3. 每个 session 结束前跑全量 pytest
4. 如果发现其他流水线的代码有问题，在 CONTEXT.md 中记录，不要自行修复
