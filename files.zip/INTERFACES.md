# CodeBook — 模块接口契约

> 本文件定义模块间的数据格式和调用约定。
> **任何流水线修改接口前，必须先更新本文件，再改代码。**
> 接口变更需在 CONTEXT.md 中标注，通知其他流水线。

---

## 核心数据流

```
用户输入 (repo_url / question / instruction)
    ↓
[server.py] ─── MCP 协议路由 ───→ [tools/*]
                                      ↓
                                [parsers/*] ── Tree-sitter AST
                                      ↓
                                [NetworkX] ── 依赖图
                                      ↓
                              工具输出 (JSON / Mermaid / Diff)
```

---

## 1. 解析器输出格式（parsers/ → tools/）

### 1.1 AST 解析结果

```python
@dataclass
class ParsedSymbol:
    name: str                    # 符号名称（函数名/类名/变量名）
    kind: str                    # "function" | "class" | "method" | "variable" | "import"
    file_path: str               # 相对于仓库根目录的路径
    start_line: int              # 起始行号（1-indexed）
    end_line: int                # 结束行号（1-indexed）
    signature: str | None        # 函数/方法签名（含参数和返回类型）
    docstring: str | None        # 文档字符串
    parent: str | None           # 所属类名（method 才有）
    decorators: list[str]        # 装饰器列表
```

### 1.2 模块分组结果

```python
@dataclass
class Module:
    name: str                    # 模块名（通常是目录名或文件名）
    path: str                    # 模块根路径
    files: list[str]             # 包含的文件路径列表
    symbols: list[ParsedSymbol]  # 模块内所有符号
    description: str | None      # 模块摘要（由 LLM 生成或从 docstring 提取）
```

### 1.3 依赖图结构

```python
# NetworkX DiGraph
# 节点：Module.name 或 "{file_path}::{symbol_name}"
# 边属性：
edge_attrs = {
    "type": str,     # "imports" | "calls" | "inherits" | "uses"
    "source_line": int,
    "target_line": int,
}
```

**⚠️ 约束**：依赖图的节点 ID 格式一旦确定不可随意变更，所有 tool 都依赖这个格式做查询。

---

## 2. Tool 输入输出契约

### 2.1 scan_repo

**输入**：
```python
{
    "repo_url": str,           # Git 仓库 URL（必填）
    "depth": str,              # "overview" | "detailed"（默认 "overview"）
}
```

**输出**：
```python
{
    "modules": list[Module],            # 模块列表
    "dependency_graph": str,            # Mermaid 格式的全局依赖图
    "stats": {
        "total_files": int,
        "total_lines": int,
        "total_symbols": int,
        "total_modules": int,
        "scan_duration_ms": int,
    },
    "blueprint_json": dict,             # 完整蓝图结构化数据
}
```

### 2.2 read_chapter

**输入**：
```python
{
    "module_name": str,        # 模块名称（支持精确/目录/模糊匹配）
}
```

**输出**：
```python
{
    "module": Module,
    "subcomponents": list[ParsedSymbol],  # 子组件列表
    "call_graph": str,                     # 模块内 Mermaid 调用关系图
    "branch_logic": list[dict],            # 分支逻辑摘要
    "external_dependencies": list[str],    # 外部依赖的模块名
}
```

### 2.3 diagnose

**输入**：
```python
{
    "description": str,        # 自然语言问题描述（必填）
    "module_name": str | None, # 可选，缩小搜索范围
}
```

**输出**：
```python
{
    "flow_chart": str,                     # Mermaid 流程图
    "locations": list[{
        "file": str,
        "line": int,
        "symbol": str,
        "relevance": str,                  # 自然语言说明为什么相关
    }],
    "root_cause_hypothesis": str,          # 自然语言根因假设
    "suggested_next_steps": list[str],
}
```

### 2.4 ask_about

**输入**：
```python
{
    "module_name": str,        # 模块名称（必填）
    "question": str,           # 自然语言问题（必填）
    "conversation_history": list[dict] | None,  # 多轮对话历史
}
```

**输出**：
```python
{
    "answer": str,             # 自然语言回答
    "references": list[{       # 引用的代码位置
        "file": str,
        "line": int,
        "snippet": str,
    }],
}
```

### 2.5 codegen

**输入**：
```python
{
    "instruction": str,        # 自然语言修改指令（必填）
    "locate_result": dict | None,  # diagnose 的输出（可选，提高精度）
}
```

**输出**：
```python
{
    "diffs": list[{
        "file": str,
        "unified_diff": str,           # 标准 unified diff 格式
        "before_snippet": str,
        "after_snippet": str,
    }],
    "impact_analysis": {
        "affected_modules": list[str],
        "affected_tests": list[str],
        "risk_level": str,             # "低" | "中" | "高"
    },
    "verification_steps": list[str],   # 验证步骤
}
```

---

## 3. 角色系统接口（即将重构）

**当前**：4 角色（ceo/pm/investor/qa），通过 prompt 前缀切换输出风格。

**计划重构为**：PM↔Dev 桥梁模型

```python
{
    "viewer_role": str,        # "pm" | "dev"（简化为两种）
    "project_domain": str | None,  # 项目领域描述（用于术语适配）
    "viewer_context": str | None,  # 查看者的额外上下文
}
```

**⚠️ 重构约束**：
- 对外接口保持向后兼容（旧的 ceo/investor/qa 映射到 pm）
- 不改变 tool 的输入输出格式，只影响输出的自然语言风格
- 重构完成后更新本文件

---

## 4. 文件存储约定

| 路径 | 用途 | 持久化 |
|------|------|--------|
| `repos/` | clone 的测试仓库 | 不提交到 CodeBook 仓库 |
| `test_results/` | 压力测试结果 | 按项目名建子目录 |
| `src/config/` | Prompt 配置文件 | 提交 |
| `.codebook/` | 运行时缓存（AST 缓存、索引） | 不提交 |

---

## 变更记录

| 日期 | 变更内容 | 影响的模块 |
|------|---------|-----------|
| 2026-03-22 | 初始版本，基于 MCP v0.1 接口整理 | 全部 |
